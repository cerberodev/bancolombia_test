import 'package:flutter/material.dart';

class BancolombiaColors {
  static const Color brilliantRed = Color(0xFFA1B1C1);
}
