import 'package:flutter/material.dart';

class BancolombiaSplashPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
